// Import necessary Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Function to load recipe details based on the ID in the URL
async function loadRecipeDetails() {
  // Get the recipe ID from the query parameters
  const urlParams = new URLSearchParams(window.location.search);
  const recipeId = urlParams.get("id");

  if (!recipeId) {
    console.error("Recipe ID is missing in the URL!");
    return;
  }

  try {
    // Fetch the recipe document from Firestore
    const recipeDocRef = doc(db, "recipes", recipeId);
    const recipeDoc = await getDoc(recipeDocRef);

    if (recipeDoc.exists()) {
      const recipeData = recipeDoc.data();

      // Populate the page with the recipe details
      document.getElementById("recipe-title").textContent = recipeData.title || "Untitled Recipe";
      document.getElementById("recipe-creator").querySelector("span").textContent = recipeData.creator || "Unknown";

      // Add recipe image
      const recipeImage = document.getElementById("recipe-image");
      recipeImage.src = recipeData.imageUrl || "images/placeholder-recipe.jpg";
      recipeImage.alt = recipeData.title || "Recipe Image";

      // Add ingredients
      const ingredientsList = document.getElementById("ingredients-list");
      ingredientsList.innerHTML = ""; // Clear previous content
      (recipeData.ingredients || []).forEach((ingredient) => {
        const listItem = document.createElement("li");
        listItem.textContent = ingredient;
        ingredientsList.appendChild(listItem);
      });

      // Add instructions
      document.getElementById("instructions").textContent = recipeData.instructions || "No instructions provided.";
    } else {
      console.error("No such recipe found!");
      document.querySelector(".recipe-container").textContent = "Recipe not found.";
    }
  } catch (error) {
    console.error("Error fetching recipe details:", error);
    document.querySelector(".recipe-container").textContent = "An error occurred while loading the recipe.";
  }
}

// Call the function when the DOM is fully loaded
document.addEventListener("DOMContentLoaded", loadRecipeDetails);

// Get elements
const addReviewBtn = document.getElementById("addReviewBtn");
const reviewModal = document.getElementById("reviewModal");
const closeModalBtn = document.getElementById("closeModalBtn");
const submitReviewBtn = document.getElementById("submitReviewBtn");
const reviewText = document.getElementById("reviewText");
const reviewList = document.getElementById("reviewList");

// Open modal when the "Add a Review" button is clicked
addReviewBtn.onclick = function() {
  reviewModal.style.display = "block";
}

closeModalBtn.onclick = function() {
  reviewModal.style.display = "none";
}

window.onclick = function(event) {
  if (event.target === reviewModal) {
    reviewModal.style.display = "none";
  }
}

submitReviewBtn.onclick = function() {
  const review = reviewText.value.trim();
  if (review) {
  
    const newReview = document.createElement("li");
    newReview.textContent = review;

    reviewList.appendChild(newReview);

    reviewText.value = "";
    reviewModal.style.display = "none";
  } else {
    alert("Please write a review before submitting.");
  }
}

