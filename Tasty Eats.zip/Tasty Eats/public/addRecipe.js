// Import necessary Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
  authDomain: "tastyeats-995f5.firebaseapp.com",
  projectId: "tastyeats-995f5",
  storageBucket: "tastyeats-995f5.appspot.com",
  messagingSenderId: "137077111231",
  appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
  measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Check if user is logged in before allowing them to add a recipe
let currentUser = null;

// Monitor authentication state
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
  } else {
    alert("You must be logged in to add a recipe.");
    window.location.href = "index.html"; // Redirect to login page if not logged in
  }
});

// Set up Cloudinary upload widget for recipe images
document.getElementById("uploadWidget").addEventListener("click", function () {
  cloudinary.openUploadWidget(
    {
      cloudName: "dgdzmrhc4",
      uploadPreset: "recipe-images-upload",
      folder: "recipe_images",
      sources: ["local", "url"],
    },
    (error, result) => {
      if (error) {
        alert("Error uploading image. Please try again.");
        console.error("Error uploading image:", error);
      } else if (result && result.event === "success") {
        // Display the uploaded image URL in the form
        document.getElementById("imageURL").value = result.info.secure_url;

        // Show a preview of the uploaded image
        const previewElement = document.getElementById("imagePreview");
        if (previewElement) {
          previewElement.src = result.info.secure_url;
          previewElement.style.display = "block";
        }
      }
    }
  );
});

// Popup controls
const popup = document.getElementById("popup");
const popupOkButton = document.getElementById("popup-ok");

function openPopup() {
  popup.classList.add("open-popup");
}

function closePopup() {
  popup.classList.remove("open-popup");
  window.location.href='landing.html';
}

popupOkButton.addEventListener("click", closePopup);

const recipeForm = document.getElementById("recipeForm");
recipeForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const recipeTitle = document.getElementById("recipeTitle").value.trim();
  const instructions = document.getElementById("instructions").value.trim();
  const ingredients = document.getElementById("ingredients").value.trim().split(",");
  const imageUrl = document.getElementById("imageURL").value;

  if (!recipeTitle || !instructions || !ingredients.length || !imageUrl) {
    alert("Please fill out all fields, including the image!");
    return;
  }

  try {
    if (!currentUser) {
      alert("You must be logged in to add a recipe.");
      return;
    }

    await addDoc(collection(db, "recipes"), {
      title: recipeTitle,
      instructions,
      ingredients,
      imageUrl,
      userId: currentUser.uid,
      timestamp: new Date(),
    });

    openPopup(); 
    recipeForm.reset();

    const previewElement = document.getElementById("imagePreview");
    if (previewElement) {
      previewElement.style.display = "none";
    }
  } catch (error) {
    console.error("Error adding recipe:", error);
    alert("Failed to add recipe. Please try again.");
  }
});

const uploadButton = document.getElementById("uploadWidget");
const imageInput = document.getElementById("imageInput");
const imagePreview = document.getElementById("imagePreview");

uploadButton.addEventListener("click", () => {

    imageInput.click();
});

imageInput.addEventListener("change", function () {
    const file = this.files[0]; 

    if (file) {
        const reader = new FileReader();

        reader.onload = function (event) {
            imagePreview.src = event.target.result;

            imagePreview.style.display = "block"; 


            uploadButton.style.display = "none"; 
        };

        reader.readAsDataURL(file);
    }
});


