document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('updateProfileForm');
    const avatarUpload = document.getElementById('avatar-upload');
    const displayPhoto = document.getElementById('display-photo');

    // Handle profile picture upload and preview
    avatarUpload.addEventListener('change', (event) => {
        const file = event.target.files[0];
        if (file && (file.type === 'image/png' || file.type === 'image/jpeg')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                displayPhoto.src = e.target.result; // Update the profile picture preview
                localStorage.setItem('profilePhoto', e.target.result); // Save the image in localStorage
            };
            reader.readAsDataURL(file);
        } else {
            alert('Please upload a valid image file (PNG or JPG).');
        }
    });

    // Handle form submission
    form.addEventListener('submit', async (event) => {
        event.preventDefault(); // Prevent the default form submission

        const username = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const bio = document.getElementById('bio').value.trim();

        // Basic validation
        if (!username || !email || !validateEmail(email)) {
            alert('Please enter a valid username and email.');
            return;
        }

        try {
            // Simulate profile update API call
            const response = await fakeApiCall({ username, email, bio });

            if (response.success) {
                // Save updated information to localStorage
                localStorage.setItem('username', username);
                localStorage.setItem('email', email);
                localStorage.setItem('bio', bio);

                alert('Profile updated successfully!');
                window.location.href = 'profile.html'; // Redirect to the profile page
            } else {
                alert(`Error: ${response.message}`);
            }
        } catch (error) {
            console.error('An error occurred:', error);
            alert('An unexpected error occurred. Please try again later.');
        }
    });

    // Email validation function
    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Simulated API call function (replace with your backend logic)
    async function fakeApiCall(profileData) {
        return new Promise((resolve) => {
            setTimeout(() => {
                // Mock response: accept any valid data as "successful"
                if (profileData.username && profileData.email) {
                    resolve({ success: true });
                } else {
                    resolve({ success: false, message: 'Invalid input' });
                }
            }, 1000); // Simulate a 1-second delay
        });
    }
});
