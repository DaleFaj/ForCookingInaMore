// Import Firebase modules
import {
    getAuth,
    updateProfile,
    onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import {
    getFirestore,
    doc,
    updateDoc,
    getDoc,
} from "https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// DOM Elements
const form = document.getElementById("updateProfileForm");
const usernameInput = document.getElementById("name");
const bioInput = document.getElementById("bio");

// Load user data
onAuthStateChanged(auth, async (user) => {
    if (user) {
        try {
            usernameInput.value = user.displayName || "";

            // Fetch bio from Firestore
            const userDocRef = doc(db, "users", user.uid);
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
                bioInput.value = userDoc.data().bio || "";
            }
        } catch (error) {
            console.error("Error loading user data:", error);
        }
    } else {
        // Redirect to login if no user is signed in
        window.location.href = "login.html";
    }
});

// Update user details
form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const user = auth.currentUser;

    if (!user) {
        console.error("No user signed in.");
        return;
    }

    const newUsername = usernameInput.value.trim();
    const newBio = bioInput.value.trim();

    try {
        // Update profile in Firebase Authentication
        if (newUsername && newUsername !== user.displayName) {
            await updateProfile(user, { displayName: newUsername });
        }

        // Update user data in Firestore
        const userDocRef = doc(db, "users", user.uid);
        await updateDoc(userDocRef, { 
            bio: newBio, 
            username: newUsername // Update username in Firestore
        });

        alert("Profile updated successfully!");
    } catch (error) {
        console.error("Error updating profile:", error);
        alert("Failed to update profile. Please try again.");
    }
});