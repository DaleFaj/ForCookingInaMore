// Dropdown Functionality
document.addEventListener('DOMContentLoaded', () => {
    const dropdown = document.querySelector('.dropdown');
    const dropdownBtn = document.querySelector('.dropdown-btn');
    const dropdownOptions = document.querySelectorAll('.dropdown-option');
    const recipeGrid = document.querySelector('.recipe-grid');
  
    // Toggle dropdown visibility
    dropdownBtn.addEventListener('click', () => {
      dropdown.querySelector('.dropdown-content').classList.toggle('show');
    });
  
    // Handle dropdown option selection
    dropdownOptions.forEach(option => {
      option.addEventListener('click', (e) => {
        const selectedValue = e.target.getAttribute('data-value');
        dropdownBtn.textContent = e.target.textContent + ' ▼'; // Update button text
        dropdown.querySelector('.dropdown-content').classList.remove('show');
  
        // Sorting functionality (example)
        if (selectedValue === 'newest') {
          sortRecipesByNewest(recipeGrid);
        } else if (selectedValue === 'oldest') {
          sortRecipesByOldest(recipeGrid);
        }
      });
    });
  
    // Close dropdown if clicked outside
    window.addEventListener('click', (e) => {
      if (!dropdown.contains(e.target)) {
        dropdown.querySelector('.dropdown-content').classList.remove('show');
      }
    });
  });
  
  // Navigate to recipe page
  function navigateToRecipe(url) {
    window.location.href = url;
  }
  
  // Delete a recipe card
  document.addEventListener('click', (e) => {
    if (e.target.closest('.delete-btn')) {
      const card = e.target.closest('.recipe-card');
      if (card) {
        card.remove(); // Remove the recipe card
      }
    }
  });
  
  // Sort recipes by "newest" (for demonstration, reversing the order)
  function sortRecipesByNewest(grid) {
    const cards = Array.from(grid.children);
    cards.reverse(); // Reverse the card order
    cards.forEach(card => grid.appendChild(card));
  }
  
  // Sort recipes by "oldest" (restore original order)
  function sortRecipesByOldest(grid) {
    const cards = Array.from(grid.children);
    cards.sort((a, b) => a.dataset.index - b.dataset.index); // Sort by original order
    cards.forEach(card => grid.appendChild(card));
  }
  