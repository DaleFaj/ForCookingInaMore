// Initialize Firebase (ensure this is included)
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-auth.js";
import { getFirestore, doc, getDoc, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyC-jzE75K43fOXM-J_o_XxGv-Z_wwcJpNY",
    authDomain: "tastyeats-995f5.firebaseapp.com",
    projectId: "tastyeats-995f5",
    storageBucket: "tastyeats-995f5.appspot.com",
    messagingSenderId: "137077111231",
    appId: "1:137077111231:web:3cefa693c4a9c5f920890a",
    measurementId: "G-JE7X98TVX1",
};

// Initialize Firebase app and services
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// DOM Elements
const usernameElement = document.querySelector('.profile-info h2');
const bioElement = document.querySelector('.Description');
const recipeCountElement = document.querySelector('.Recipes-count'); // For recipe count
const recipeGrid = document.getElementById('recipeGrid'); // For displaying user recipes
const logoutButton = document.getElementById('logoutButton'); // Logout button element

// Static bio for all users (can be replaced with dynamic bio later if needed)
const staticBio = "I am a dedicated chef passionate about creating delicious and innovative dishes, blending flavors and techniques to craft memorable culinary experiences.";

// Set default bio
bioElement.textContent = staticBio;

// Fetch and display user data
onAuthStateChanged(auth, async (user) => {
    if (user) {
        const userDocRef = doc(db, "users", user.uid); // Adjust "users" to match your Firestore collection name
        try {
            // Fetch user data
            const userDoc = await getDoc(userDocRef);
            if (userDoc.exists()) {
                const username = userDoc.data().username; // Ensure Firestore has a "username" field
                usernameElement.textContent = username || "Default Username";

                // You can also make the bio dynamic if stored in Firestore
                const userBio = userDoc.data().bio || staticBio;
                bioElement.textContent = userBio;

                // Fetch and display user-specific recipes
                fetchUserRecipes(user.uid);
            } else {
                console.error("User document not found!");
            }
        } catch (error) {
            console.error("Error fetching user data:", error);
        }
    } else {
        // If no user is logged in, redirect to login page
        window.location.href = "index.html";
    }
});

// Function to fetch and display recipes posted by the logged-in user
async function fetchUserRecipes(userId) {
    const recipesRef = collection(db, "recipes"); // Adjust "recipes" to match your Firestore collection name
    const q = query(recipesRef, where("userId", "==", userId));

    try {
        const querySnapshot = await getDocs(q);
        recipeGrid.innerHTML = ""; // Clear the grid before adding recipes
        if (querySnapshot.empty) {
            recipeGrid.innerHTML = "<p>No recipes found.</p>";
            recipeCountElement.textContent = "Recipes: 0"; // Show 0 when no recipes
            return;
        }

        let recipeCount = 0; // Counter for recipes
        querySnapshot.forEach((doc) => {
            const recipe = doc.data();
            const recipeCard = createRecipeCard(recipe);
            recipeGrid.appendChild(recipeCard);
            recipeCount++;
        });

        // Display recipe count
        recipeCountElement.textContent = `Recipes: ${recipeCount}`;
    } catch (error) {
        console.error("Error fetching user recipes:", error);
    }
}

// Function to create a recipe card element
function createRecipeCard(recipe) {
    const card = document.createElement("div");
    card.className = "recipe-card";

    card.innerHTML = `
        <img src="${recipe.imageUrl}" alt="${recipe.title}">
        <p>${recipe.title}</p>
        <p>⭐⭐⭐⭐⭐ (${recipe.ratingCount})</p>
        <button class="delete-btn">
            <img src="images/delete_icon.png" alt="Delete">
        </button>
    `;
    return card;
}

// Logout functionality
if (logoutButton) {
    logoutButton.addEventListener('click', async () => {
        try {
            await signOut(auth);
            window.location.href = "index.html"; // Redirect to login page after logout
        } catch (error) {
            console.error("Error during logout:", error);
        }
    });
}